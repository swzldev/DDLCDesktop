# VERY IMPORTANT

If you havn't read the installation instructions on the [github](https://github.com/swzldev/DDLCDesktop/), do it now. The application wont work out of the box!
Since this version, this video is now outdated, as the setup is (mostly) in-app, therefore you do not need to setup the config.json manually. However, you still need to extract the assets from the game, so I've left the video link here. You should ONLY use the first 4 parts (0:00-4:41), aka intro, download, assets and font (optional). If you watch any more, it will technically still work but is slightly more complicated than the in-app guide. So you should stop the tutorial there and just open the app as normal and follow the instructions on screen.
You can access the video [here](https://www.youtube.com/watch?v=a_A4Sm2gPh0).

# RESETTING

If you're experiencing major issues, you can use the `reset.bat` file included with the app. This does a hard reset of the character state. It is recommended that you first use the 'Reset' button in the app first as this is mostly a legacy feature that isn't really needed anymore.
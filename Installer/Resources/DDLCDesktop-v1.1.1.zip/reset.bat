@echo off

echo Deleting log...
del log.txt
echo Deleting character state...
del character_state.json

echo Done.